# Charlie MJ YouTube — Feature Matrix

- Countries & Regions: search/select country; country-specific JSON; city/region signals
- Languages: complete bundled dataset with live search from A–Z
- Geographic modes: Strict, Balanced, Priority, Whitelist
- Privacy Rules: channel whitelist/blocklist and keyword whitelist/blocklist
- YouTube tools: Shorts and sidebar controls, page scanning
- YouTube Fetch: visible video metadata from active YouTube pages
- Suggestions: local transparent scoring
- Algorithm Insights: explanation of heuristic scoring
- Database: JSON-first datasets and user backup/restore
- Data Sync: GitHub public data comparison/preview
- Performance: scan metrics
- Notifications: visible save/test notifications
- Diagnostics: scan state and reasons
- Import/Export: JSON backup and rule transfer


### YouTube Ad Control
- Dedicated ad-protection tab
- Network blocking rules
- Cosmetic ad-slot and overlay removal
- Video-ad skip/fast-forward assist
- Basic/Balanced/Aggressive modes
- Local ad statistics
- Toolbar quick toggle
